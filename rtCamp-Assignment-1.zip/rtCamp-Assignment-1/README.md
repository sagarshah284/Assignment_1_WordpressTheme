# AScreative #

  Version:  1.0.0

* **Author:** AKASH SONI

* **License:** [GPL v2 or later] (http://www.gnu.org/licenses/gpl-2.0.html)

## Description ##
	This is One Wordpress Theme, Which is use for display detail of post data and you can also show data in slider.

## Installation ##

### Upload the theme ###


1. Download Theme.
   [Download] (https://github.com/akashsonic/ascreative/archive/master.zip)

2. Go to **Appearance > Themes** in the WordPress Dashboard

3. Click on the Add New button

4. Click on the Upload link

5. Select the ascreative-master.zip file

6. Click Install Now


### Activate the theme ###

1. Go to **Appearance > Themes** in the WordPress menu

2. Hover over the theme thumbnail and press the Activate button

## Custom Menu ##

### Set up Custom Header Menu ###

1. Go to **Appearance > Menus** in the WordPress menu

2. Click on Create a new menu link

3. Give a name to your menu in Menu Name and click Create Menu button

4. Now choose the pages, categories, custom links from the left-side of your screen by selecting the checkbox and click on Add Menu

5. Now choose the Theme locations Primary Menu option select

6. Click Save Menu after adding required pages, categories in the menu

### Set up Custom Footer Menu ###

1. Go to **Appearance > Menus** in the WordPress menu

2. Click on Create a new menu link

3. Give a name to your menu in Menu Name and click Create Menu button

4. Now choose the pages, categories, custom links from the left-side of your screen by selecting the checkbox and click on Add Menu

5. Now choose the Theme locations Social Links Menu option select

6. Click Save Menu after adding required pages, categories in the menu

##Home Page##

1. Go to **Pages > Add new** in the WordPress menu

2. Enter page title name "Home"

3. Now go **Page Attributes > Template** select Home

4. Click Publish button

5. Go to **Setting > Reading** in the WordPress menu

6. Select **A static page > Front page** select Home

7. Click Save Changes Button


##Home Page Based Slider##

1. Go to **Based Slider > Add new** in the WordPress menu

2. Enter slider title name

3. Write Excerpt or content data

4. Now Go set Featured Image or Add Image in content

5. On Home Page maximum 5 slider show in Based Slider

##Set Home Child page ##

1. Go to **Page > Add new** in the WordPress menu

2. Enter slider title name

3. Write Excerpt or content data

4. Now Go set Featured Image or Add Image in content

5. Now go page Attributes and choise parent page "Home"

6. Click publish button ( maximum 4 child page show on home page )

7. After create Home child page you create sub child page of this pages and publiched

8. One home child page show Three Sub child detail on home page

5. On home page maximum 5 slider show in Based Slider

##Setup Widgets ##

1. Go to **Appearance > Widgets** in the WordPress menu

2. Now remove all widget show in footer area

3. Now one by one Add this Widgets **Choice Category Post** , **Text** , **Social Link **and **Custom Menu** in footer area

### Set Choice Category Post Widgets ###

1. Go to **Post > Categories** in the WordPress menu

2. Enter Category name

3. Click Add new category button

4. Go to **Post > Add New** in the WordPress menu

5. Enter Post Title & Content

6. Now go Categories Box and choice youe category

7. Click Publish Button

8. Repeat step 4 to 7 and create postes You need

9. Go to **Appearance > Widgets** in the WordPress menu

10. Go Footer area and click Choice Category Post widget

11. Add Widget Title text

12. Select number of post you show ( Minmum 1 , maximum 5 post you show )

13. Choice post category  name

14. Click save button

### Set Text Widgets ###

1. Go to **Appearance > Widgets** in the WordPress menu

2. Go Footer area and click Text widget

3. Add Widget Title text

4. Write HTML code or content you show

5. Click save button

### Set Social Links Widgets ###

1. Go to **Appearance > Widgets** in the WordPress menu

2. Go Footer area and click Social Links Widget

3. Add Widget Title text

4. Set Facebook , Twitter , Linkedin and Rss links in text box

5. Click save button

### Set Custom Menu Widgets ###

1. Go to **Appearance > Menus** in the WordPress menu

2. Create new menu

3. Go to **Appearance > Widgets** in the WordPress menu

4. Go Footer area and click Custom Menu widget

5. Add Widget Title text

6. Select Menu name you create

7. Click save button





**Now complete theme setup steps**

Thank You...


